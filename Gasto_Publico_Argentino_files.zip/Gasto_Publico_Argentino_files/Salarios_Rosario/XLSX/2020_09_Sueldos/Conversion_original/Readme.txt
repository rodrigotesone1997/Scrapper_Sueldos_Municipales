Estos .xlsx fueron la conversion directa que se hizo de los pdf en la pagina:

https://www.ilovepdf.com/